﻿
namespace hw1HickeyThomas
{
    partial class StockQuotes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSP = new System.Windows.Forms.TextBox();
            this.lblSp = new System.Windows.Forms.Label();
            this.txtSC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPP = new System.Windows.Forms.TextBox();
            this.lblPP = new System.Windows.Forms.Label();
            this.txtPC = new System.Windows.Forms.TextBox();
            this.lblPC = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.txtProfit = new System.Windows.Forms.TextBox();
            this.lblProfit = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculateStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resetStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNS
            // 
            this.txtNS.Location = new System.Drawing.Point(62, 59);
            this.txtNS.Name = "txtNS";
            this.txtNS.Size = new System.Drawing.Size(143, 27);
            this.txtNS.TabIndex = 0;
            this.txtNS.Text = "0";
            this.txtNS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(230, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number of Shares";
            // 
            // txtSP
            // 
            this.txtSP.Location = new System.Drawing.Point(62, 118);
            this.txtSP.Name = "txtSP";
            this.txtSP.Size = new System.Drawing.Size(143, 27);
            this.txtSP.TabIndex = 2;
            this.txtSP.Text = "0";
            this.txtSP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblSp
            // 
            this.lblSp.AutoSize = true;
            this.lblSp.Location = new System.Drawing.Point(230, 122);
            this.lblSp.Name = "lblSp";
            this.lblSp.Size = new System.Drawing.Size(146, 20);
            this.lblSp.TabIndex = 3;
            this.lblSp.Text = "Sales Price per Share";
            // 
            // txtSC
            // 
            this.txtSC.Location = new System.Drawing.Point(62, 175);
            this.txtSC.Name = "txtSC";
            this.txtSC.Size = new System.Drawing.Size(143, 27);
            this.txtSC.TabIndex = 4;
            this.txtSC.Text = "0";
            this.txtSC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(230, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sales Commission Paid";
            // 
            // txtPP
            // 
            this.txtPP.Location = new System.Drawing.Point(62, 236);
            this.txtPP.Name = "txtPP";
            this.txtPP.Size = new System.Drawing.Size(143, 27);
            this.txtPP.TabIndex = 6;
            this.txtPP.Text = "0";
            this.txtPP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPP
            // 
            this.lblPP.AutoSize = true;
            this.lblPP.Location = new System.Drawing.Point(230, 237);
            this.lblPP.Name = "lblPP";
            this.lblPP.Size = new System.Drawing.Size(170, 20);
            this.lblPP.TabIndex = 7;
            this.lblPP.Text = "Purchase Price per Share";
            // 
            // txtPC
            // 
            this.txtPC.Location = new System.Drawing.Point(62, 295);
            this.txtPC.Name = "txtPC";
            this.txtPC.Size = new System.Drawing.Size(143, 27);
            this.txtPC.TabIndex = 8;
            this.txtPC.Text = "0";
            this.txtPC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPC
            // 
            this.lblPC.AutoSize = true;
            this.lblPC.Location = new System.Drawing.Point(230, 302);
            this.lblPC.Name = "lblPC";
            this.lblPC.Size = new System.Drawing.Size(184, 20);
            this.lblPC.TabIndex = 9;
            this.lblPC.Text = "Purchase Commission Paid";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(460, 389);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(126, 29);
            this.btnReset.TabIndex = 10;
            this.btnReset.Text = "Reset Form";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(216, 389);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(126, 29);
            this.btnCalc.TabIndex = 11;
            this.btnCalc.Text = "Calculate Profit";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtProfit
            // 
            this.txtProfit.Location = new System.Drawing.Point(476, 175);
            this.txtProfit.Name = "txtProfit";
            this.txtProfit.ReadOnly = true;
            this.txtProfit.Size = new System.Drawing.Size(143, 27);
            this.txtProfit.TabIndex = 12;
            // 
            // lblProfit
            // 
            this.lblProfit.AutoSize = true;
            this.lblProfit.Location = new System.Drawing.Point(631, 179);
            this.lblProfit.Name = "lblProfit";
            this.lblProfit.Size = new System.Drawing.Size(115, 20);
            this.lblProfit.TabIndex = 13;
            this.lblProfit.Text = "Profit From Sale";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(802, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculateStripMenuItem1,
            this.resetStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(33, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // calculateStripMenuItem1
            // 
            this.calculateStripMenuItem1.Name = "calculateStripMenuItem1";
            this.calculateStripMenuItem1.Size = new System.Drawing.Size(123, 26);
            this.calculateStripMenuItem1.Text = "&Calculate";
            this.calculateStripMenuItem1.Click += new System.EventHandler(this.button2_Click);
            // 
            // resetStripMenuItem1
            // 
            this.resetStripMenuItem1.Name = "resetStripMenuItem1";
            this.resetStripMenuItem1.Size = new System.Drawing.Size(123, 26);
            this.resetStripMenuItem1.Text = "&Reset";
            this.resetStripMenuItem1.Click += new System.EventHandler(this.button1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(338, 447);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(126, 29);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // StockQuotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 666);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblProfit);
            this.Controls.Add(this.txtProfit);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblPC);
            this.Controls.Add(this.txtPC);
            this.Controls.Add(this.lblPP);
            this.Controls.Add(this.txtPP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSC);
            this.Controls.Add(this.lblSp);
            this.Controls.Add(this.txtSP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNS);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "StockQuotes";
            this.Text = "Stock Quotes";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSP;
        private System.Windows.Forms.Label lblSp;
        private System.Windows.Forms.TextBox txtSC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPP;
        private System.Windows.Forms.Label lblPP;
        private System.Windows.Forms.TextBox txtPC;
        private System.Windows.Forms.Label lblPC;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.TextBox txtProfit;
        private System.Windows.Forms.Label lblProfit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculateStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem resetStripMenuItem1;
        private System.Windows.Forms.Button btnExit;
    }
}

