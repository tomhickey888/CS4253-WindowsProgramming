﻿using System;
using System.Windows.Forms;

namespace hw1HickeyThomas
{
    public partial class StockQuotes : Form
    {
        public StockQuotes()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StockQuotes NewForm = new StockQuotes();
            NewForm.Show();
            this.Dispose(false);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtNS.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter the number of shares");
                return; // return because we don't want to run normal code of buton click
            }
            int NS = Convert.ToInt32(txtNS.Text);
            if (txtSP.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter the sales price");
                return; // return because we don't want to run normal code of buton click
            }
            double SP = Convert.ToDouble(txtSP.Text);
            if (txtSC.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter the sales commission");
                return; // return because we don't want to run normal code of buton click
            }
            double SC = Convert.ToDouble(txtSC.Text);
            if (txtPP.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter the purchase price");
                return; // return because we don't want to run normal code of buton click
            }
            double PP = Convert.ToDouble(txtPP.Text);
            if (txtPC.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter the purchase commission");
                return; // return because we don't want to run normal code of buton click
            }
            double PC = Convert.ToDouble(txtPC.Text);

            double profit = ((NS * SP) - SC) - ((NS * PP) + PC);

            txtProfit.Text = profit.ToString();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
